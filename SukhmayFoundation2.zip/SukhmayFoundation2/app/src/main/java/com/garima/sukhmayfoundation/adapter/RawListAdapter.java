package com.garima.sukhmayfoundation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.garima.sukhmayfoundation.R;
import com.garima.sukhmayfoundation.model.Rawmodel;

import java.util.ArrayList;

public class RawListAdapter extends RecyclerView.Adapter<RawListAdapter.Myviewholder>
{
    Context context;
    ArrayList<Rawmodel> list;
    public RawListAdapter(Context context, ArrayList<Rawmodel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public Myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.rawdata,parent,false);
        return new Myviewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Myviewholder holder, int position) {

        Rawmodel obj=list.get(position);
        holder.sector.setText("Sector:- "+obj.getSector());
        holder.task.setText("Task:- "+obj.getTask());
        holder.desc.setText("Description:- "+obj.getDesc());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class Myviewholder extends RecyclerView.ViewHolder
    {
        TextView sector,task,desc;

        public Myviewholder(@NonNull View itemView) {
            super(itemView);
            sector=itemView.findViewById(R.id.txt12);
            task=itemView.findViewById(R.id.txt13);
            desc=itemView.findViewById(R.id.txt14);
        }
    }
}
