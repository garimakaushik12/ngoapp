package com.garima.sukhmayfoundation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.garima.sukhmayfoundation.R;
import com.garima.sukhmayfoundation.model.WorkdoneModel;

import java.util.ArrayList;

public class WorkDoneAdapter extends RecyclerView.Adapter<WorkDoneAdapter.MyViewHolder>
{
    Context context;
    ArrayList<WorkdoneModel> list;

    public WorkDoneAdapter(Context context, ArrayList<WorkdoneModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View myview= LayoutInflater.from(context).inflate(R.layout.work_done,parent,false);
        return new MyViewHolder(myview);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        WorkdoneModel obj=list.get(position);
        holder.desc.setText("Description:- "+obj.getDesc());
        holder.date.setText("Date:- "+obj.getDate());
        holder.time.setText("Time:- "+obj.getTime());
        Glide.with(context).load(obj.getImg()).into(holder.imageView);


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder
    {
         ImageView imageView;
         TextView desc,date,time;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.working);
            desc=itemView.findViewById(R.id.txt5);
            date=itemView.findViewById(R.id.txt6);
            time=itemView.findViewById(R.id.txt7);
        }
    }
}
