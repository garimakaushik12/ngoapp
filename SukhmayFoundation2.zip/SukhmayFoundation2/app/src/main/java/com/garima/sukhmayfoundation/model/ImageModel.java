package com.garima.sukhmayfoundation.model;

public class ImageModel
{
    int image;

    public ImageModel(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }


}
