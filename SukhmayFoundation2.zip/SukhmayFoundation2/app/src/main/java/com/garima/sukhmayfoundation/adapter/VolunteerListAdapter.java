package com.garima.sukhmayfoundation.adapter;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.garima.sukhmayfoundation.R;
import com.garima.sukhmayfoundation.model.VolunteerModel;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class VolunteerListAdapter extends RecyclerView.Adapter<VolunteerListAdapter.Myviewholder>
{
    Context context;
    ArrayList<VolunteerModel> list;

    public VolunteerListAdapter(Context context, ArrayList<VolunteerModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public Myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View myview= LayoutInflater.from(context).inflate(R.layout.vol_list,parent,false);

        return new Myviewholder(myview);
    }

    @Override
    public void onBindViewHolder(@NonNull Myviewholder holder, int position) {

        VolunteerModel obj=list.get(position);
        Glide.with(context).load(obj.getImg()).into(holder.img);
        holder.name.setText("Name:- "+obj.getName());
        holder.mob.setText("Mob_no:- "+obj.getMob());
        holder.address.setText("Address:- "+obj.getAdd());
        holder.desc.setText("Description:- "+obj.getDesc());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class Myviewholder extends RecyclerView.ViewHolder
{
    CircleImageView img;
    TextView name,mob,address,desc;

    public Myviewholder(@NonNull View itemView) {
        super(itemView);
        img=itemView.findViewById(R.id.vol);
        name=itemView.findViewById(R.id.txt8);
        mob=itemView.findViewById(R.id.txt9);
        address=itemView.findViewById(R.id.txt10);
        desc=itemView.findViewById(R.id.txt11);
    }
}

}
