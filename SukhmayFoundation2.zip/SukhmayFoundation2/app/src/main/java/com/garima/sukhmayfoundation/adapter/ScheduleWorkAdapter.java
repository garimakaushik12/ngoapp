package com.garima.sukhmayfoundation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.garima.sukhmayfoundation.R;
import com.garima.sukhmayfoundation.model.data;

import java.util.ArrayList;

public class ScheduleWorkAdapter extends RecyclerView.Adapter<ScheduleWorkAdapter.MyViewHolder>
{

    Context context;

    ArrayList<data>  list;

    public ScheduleWorkAdapter(Context context, ArrayList<data> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {

        View myView= LayoutInflater.from(context).inflate(R.layout.schedule_work,parent,false);
        return new MyViewHolder(myView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position)
    {

        data obj = list.get(position);

        holder.location.setText("Location:- "+obj.getLocation());
        holder.date.setText("Date:- "+obj.getDate());
        holder.time.setText("Time:- "+obj.getTime());
        holder.desc.setText("Description:- "+obj.getDescription());

    }

    @Override
    public int getItemCount()
    {
        return list.size();
    }


    class MyViewHolder extends RecyclerView.ViewHolder
    {

        TextView location,date,time,desc;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            location = itemView.findViewById(R.id.txt1);
            date = itemView.findViewById(R.id.txt2);
            time = itemView.findViewById(R.id.txt3);
            desc = itemView.findViewById(R.id.txt4);
        }
    }



}
